import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../../services/auth_service.dart';
import '../restaurant/restaurant_dashboard.dart';
import '../ngo/ngo_dashboard.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  final String userType;

  const LoginScreen({super.key, required this.userType});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _navigateToRegister() async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (context) => RegisterScreen(userType: widget.userType),
      ),
    );
  }

  Future<void> _navigateToDashboard(String userType) async {
    if (!mounted) return;

    if (userType.toLowerCase() == 'restaurant') {
      await Navigator.pushReplacement(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const RestaurantDashboard(),
        ),
      );
    } else {
      await Navigator.pushReplacement(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const NGODashboard(),
        ),
      );
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = widget.userType.toLowerCase() == 'restaurant'
        ? Colors.green.shade600
        : Colors.orange.shade600;

    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        title: Text('${widget.userType} Login'),
        backgroundColor: themeColor,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                widget.userType.toLowerCase() == 'restaurant'
                    ? Icons.restaurant
                    : Icons.volunteer_activism,
                size: 80,
                color: themeColor,
              ),
              const SizedBox(height: 30),
              TextFormField(
                controller: _usernameController,
                decoration: const InputDecoration(
                  labelText: 'Username',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) =>
                (value == null || value.isEmpty) ? 'Please enter username' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                ),
                obscureText: true,
                validator: (value) =>
                (value == null || value.isEmpty) ? 'Please enter password' : null,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _login,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                    foregroundColor: Colors.white,
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2,
                  )
                      : const Text(
                    'Login',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: _navigateToRegister,
                child: const Text('Don\'t have an account? Register here'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final result = await ApiService.login(
        _usernameController.text.trim(),
        _passwordController.text,
      );

      if (!mounted) return;

      if (result['success'] == true) {
        final userData = result['user'] as Map<String, dynamic>;
        await AuthService.saveUserData(userData);

        if (!mounted) return;

        _showSnackBar('Login successful!');

        // Navigate to appropriate dashboard
        await _navigateToDashboard(userData['user_type'].toString());

      } else {
        _showSnackBar(
          result['message']?.toString() ?? 'Login failed',
          isError: true,
        );
      }
    } catch (e) {
      _showSnackBar('Network error occurred', isError: true);
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
