import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/food_listing.dart';
import '../../services/api_service.dart';
import '../../services/auth_service.dart';
import 'add_food_listing.dart';

class RestaurantDashboard extends StatefulWidget {
  const RestaurantDashboard({super.key});

  @override
  State<RestaurantDashboard> createState() => _RestaurantDashboardState();
}

class _RestaurantDashboardState extends State<RestaurantDashboard> {
  bool _isLoading = true;
  List<FoodListing> _myListings = [];
  int? _restaurantId;

  @override
  void initState() {
    super.initState();
    _loadMyListings();
  }

  Future<void> _loadMyListings() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    try {
      final user = await AuthService.getUserData();
      if (!mounted) return;

      if (user == null) {
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/');
        }
        return;
      }

      _restaurantId = int.tryParse(user['id'].toString());

      final res = await ApiService.getFoodListings();
      if (!mounted) return;

      if (res['success'] == true) {
        final List raw = res['listings'] ?? [];
        if (mounted) {
          setState(() {
            _myListings = raw
                .map((e) => FoodListing.fromJson(e))
                .where((l) => l.restaurantId == _restaurantId)
                .toList();
          });
        }
      } else {
        _showErrorSnackBar(res['message'] ?? 'Failed to load listings');
      }
    } catch (e) {
      _showErrorSnackBar('Network error: $e');
    }

    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  void _showErrorSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _logout() async {
    await AuthService.logout();
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/');
    }
  }

  Future<void> _navigateToAddListing() async {
    final created = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (context) => const AddFoodListingScreen(),
      ),
    );

    if (created == true && mounted) {
      _loadMyListings();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: const Text('Restaurant Dashboard'),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadMyListings,
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _buildContent(),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _navigateToAddListing,
        icon: const Icon(Icons.add),
        label: const Text('Add Listing'),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildContent() {
    if (_myListings.isEmpty) {
      return ListView(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.6,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.restaurant_menu,
                    size: 80,
                    color: Colors.green[300],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'No listings yet.\nTap the + button to add one.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.green[800],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _myListings.length,
      itemBuilder: (context, index) {
        final listing = _myListings[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          elevation: 2,
          child: ListTile(
            title: Text(
              listing.foodType,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.green[800],
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Text(listing.description),
                const SizedBox(height: 8),
                Text(
                  'Feeds ${listing.quantityPeople} people • Pickup ${DateFormat('MMM d, h:mm a').format(listing.pickupTimeStart)}',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
            trailing: Chip(
              label: Text(listing.status),
              backgroundColor: listing.status == 'available'
                  ? Colors.green[100]
                  : Colors.orange[100],
              labelStyle: TextStyle(
                color: listing.status == 'available'
                    ? Colors.green[800]
                    : Colors.orange[800],
              ),
            ),
          ),
        );
      },
    );
  }
}
