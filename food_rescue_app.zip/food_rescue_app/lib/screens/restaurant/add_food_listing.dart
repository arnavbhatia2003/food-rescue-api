import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/api_service.dart';
import '../../services/auth_service.dart';

class AddFoodListingScreen extends StatefulWidget {
  const AddFoodListingScreen({super.key});

  @override
  State<AddFoodListingScreen> createState() => _AddFoodListingScreenState();
}

class _AddFoodListingScreenState extends State<AddFoodListingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _foodTypeController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _quantityController = TextEditingController();
  final _addressController = TextEditingController();

  DateTime? _pickupStartTime;
  DateTime? _pickupEndTime;
  DateTime? _expiryTime;
  bool _isLoading = false;

  @override
  void dispose() {
    _foodTypeController.dispose();
    _descriptionController.dispose();
    _quantityController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: isError ? Colors.red : Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: const Text('Add Food Listing'),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Food Details',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[800],
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _foodTypeController,
                      decoration: const InputDecoration(
                        labelText: 'Food Type',
                        hintText: 'e.g., Indian Curry, Pizza, Sandwiches',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.restaurant),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter food type';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _descriptionController,
                      decoration: const InputDecoration(
                        labelText: 'Description',
                        hintText: 'Describe the food items available',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.description),
                      ),
                      maxLines: 3,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter description';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _quantityController,
                      decoration: const InputDecoration(
                        labelText: 'Quantity (Number of People)',
                        hintText: 'How many people can this feed?',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.people),
                      ),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter quantity';
                        }
                        if (int.tryParse(value) == null) {
                          return 'Please enter a valid number';
                        }
                        return null;
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Pickup Information',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[800],
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _addressController,
                      decoration: const InputDecoration(
                        labelText: 'Pickup Address',
                        hintText: 'Enter the pickup location',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.location_on),
                      ),
                      maxLines: 2,
                      validator: (value) => (value == null || value.isEmpty)
                          ? 'Please enter pickup address'
                          : null,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _buildDateTimeField(
                            'Pickup Start Time',
                            _pickupStartTime,
                                (dateTime) => setState(() => _pickupStartTime = dateTime),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildDateTimeField(
                            'Pickup End Time',
                            _pickupEndTime,
                                (dateTime) => setState(() => _pickupEndTime = dateTime),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    _buildDateTimeField(
                      'Food Expiry Time',
                      _expiryTime,
                          (dateTime) => setState(() => _expiryTime = dateTime),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _submitListing,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green[600],
                  foregroundColor: Colors.white,
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                  'Create Food Listing',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDateTimeField(
      String label, DateTime? selectedDate, Function(DateTime) onDateSelected) {
    return InkWell(
      onTap: () => _selectDateTime(onDateSelected),
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          prefixIcon: const Icon(Icons.schedule),
        ),
        child: Text(
          selectedDate != null
              ? DateFormat('MMM dd, yyyy HH:mm').format(selectedDate)
              : 'Select date & time',
          style: TextStyle(
            color: selectedDate != null ? Colors.black : Colors.grey,
          ),
        ),
      ),
    );
  }

  Future<void> _selectDateTime(Function(DateTime) onDateSelected) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );

    if (pickedDate != null && mounted) {
      if (!mounted) return;

      final pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );

      if (pickedTime != null && mounted) {
        final dateTime = DateTime(
          pickedDate.year,
          pickedDate.month,
          pickedDate.day,
          pickedTime.hour,
          pickedTime.minute,
        );
        onDateSelected(dateTime);
      }
    }
  }

  Future<void> _submitListing() async {
    if (!_formKey.currentState!.validate()) return;

    if (_pickupStartTime == null || _pickupEndTime == null || _expiryTime == null) {
      _showSnackBar('Please select all date and time fields', isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      final userData = await AuthService.getUserData();
      if (userData == null) {
        throw Exception('User not logged in');
      }

      final result = await ApiService.createFoodListing({
        'restaurant_id': userData['id'].toString(),
        'food_type': _foodTypeController.text.trim(),
        'description': _descriptionController.text.trim(),
        'quantity_people': _quantityController.text.trim(),
        'pickup_address': _addressController.text.trim(),
        'pickup_time_start': _pickupStartTime!.toIso8601String(),
        'pickup_time_end': _pickupEndTime!.toIso8601String(),
        'expiry_time': _expiryTime!.toIso8601String(),
      });

      if (!mounted) return;

      if (result['success'] == true) {
        _showSnackBar('Food listing created successfully!');
        Navigator.pop(context, true);
      } else {
        _showSnackBar(
          result['message'] ?? 'Failed to create listing',
          isError: true,
        );
      }
    } catch (e) {
      _showSnackBar('Network error: $e', isError: true);
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
