import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../../services/auth_service.dart';
import '../../models/food_listing.dart';

class NGODashboard extends StatefulWidget {
  const NGODashboard({super.key});

  @override
  State<NGODashboard> createState() => _NGODashboardState();
}

class _NGODashboardState extends State<NGODashboard> {
  List<FoodListing> availableListings = [];
  bool isLoading = true;
  Map<String, dynamic>? currentUser;

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadAvailableListings();
  }

  Future<void> _loadUserData() async {
    currentUser = await AuthService.getUserData();
  }

  Future<void> _loadAvailableListings() async {
    if (!mounted) return;

    setState(() => isLoading = true);

    try {
      final result = await ApiService.getFoodListings();

      if (!mounted) return;

      if (result['success'] == true) {
        final listings = result['listings'] as List;
        if (mounted) {
          setState(() {
            availableListings = listings.map((l) => FoodListing.fromJson(l)).toList();
          });
        }
      } else {
        _showErrorSnackBar('Failed to load food listings');
      }
    } catch (e) {
      _showErrorSnackBar('Network error: $e');
    }

    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  void _showErrorSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _showSuccessSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  Future<void> _logout() async {
    await AuthService.logout();
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange[50],
      appBar: AppBar(
        title: const Text('NGO Dashboard'),
        backgroundColor: Colors.orange[600],
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadAvailableListings,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadAvailableListings,
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : (availableListings.isEmpty
            ? _buildEmptyState()
            : _buildListingsView()),
      ),
    );
  }

  Widget _buildEmptyState() {
    return ListView(
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.6,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.search_off, size: 80, color: Colors.orange[300]),
              const SizedBox(height: 20),
              Text(
                'No Food Available',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange[800],
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'There are currently no surplus food listings available.\nCheck back later or contact local restaurants.',
                style: TextStyle(fontSize: 16, color: Colors.orange[600]),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: _loadAvailableListings,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange[600],
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                icon: const Icon(Icons.refresh),
                label: const Text('Refresh'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildListingsView() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: availableListings.length,
      itemBuilder: (context, index) {
        final listing = availableListings[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.restaurant, color: Colors.green[600]),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        listing.organizationName,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[800],
                        ),
                      ),
                    ),
                    Chip(
                      label: const Text('Available'),
                      backgroundColor: Colors.green[100],
                      labelStyle: TextStyle(color: Colors.green[800]),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  listing.foodType,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey[800],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  listing.description,
                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Icon(Icons.people, size: 16, color: Colors.blue[600]),
                    const SizedBox(width: 4),
                    Text(
                      'Serves ${listing.quantityPeople} people',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.blue[600],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.location_on, size: 16, color: Colors.red[600]),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        listing.pickupAddress,
                        style: TextStyle(fontSize: 14, color: Colors.red[600]),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.schedule, size: 16, color: Colors.orange[600]),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        'Pickup: ${_formatDateTime(listing.pickupTimeStart)} - ${_formatDateTime(listing.pickupTimeEnd)}',
                        style: TextStyle(fontSize: 14, color: Colors.orange[600]),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.phone, size: 16, color: Colors.grey[600]),
                        const SizedBox(width: 4),
                        Text(
                          listing.phone,
                          style: const TextStyle(fontSize: 14, color: Colors.grey),
                        ),
                      ],
                    ),
                    ElevatedButton(
                      onPressed: () => _requestPickup(listing),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange[600],
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('Request Pickup'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _formatDateTime(DateTime dateTime) =>
      '${dateTime.day}/${dateTime.month} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';

  void _requestPickup(FoodListing listing) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: const Text('Request Pickup'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Food: ${listing.foodType}'),
            Text('Restaurant: ${listing.organizationName}'),
            Text('Quantity: ${listing.quantityPeople} people'),
            const SizedBox(height: 16),
            const Text('Do you want to request pickup for this food listing?'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              _showSuccessSnackBar('Pickup request sent! (Feature coming soon)');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange[600],
              foregroundColor: Colors.white,
            ),
            child: const Text('Request'),
          ),
        ],
      ),
    );
  }
}
