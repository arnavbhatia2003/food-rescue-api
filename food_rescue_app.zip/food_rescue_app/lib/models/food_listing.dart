class FoodListing {
  final int id;
  final int restaurantId;
  final String foodType;
  final String description;
  final int quantityPeople;
  final String pickupAddress;
  final DateTime pickupTimeStart;
  final DateTime pickupTimeEnd;
  final DateTime? expiryTime;
  final String status;
  final String organizationName;
  final String phone;
  final DateTime createdAt;

  FoodListing({
    required this.id,
    required this.restaurantId,
    required this.foodType,
    required this.description,
    required this.quantityPeople,
    required this.pickupAddress,
    required this.pickupTimeStart,
    required this.pickupTimeEnd,
    this.expiryTime,
    required this.status,
    required this.organizationName,
    required this.phone,
    required this.createdAt,
  });

  factory FoodListing.fromJson(Map<String, dynamic> json) {
    return FoodListing(
      id: int.parse(json['id'].toString()),
      restaurantId: int.parse(json['restaurant_id'].toString()),
      foodType: json['food_type'] ?? '',
      description: json['description'] ?? '',
      quantityPeople: int.parse(json['quantity_people'].toString()),
      pickupAddress: json['pickup_address'] ?? '',
      pickupTimeStart: DateTime.parse(json['pickup_time_start']),
      pickupTimeEnd: DateTime.parse(json['pickup_time_end']),
      expiryTime: (json['expiry_time'] != null && json['expiry_time'].toString().isNotEmpty)
          ? DateTime.parse(json['expiry_time'])
          : null,
      status: json['status'] ?? 'available',
      organizationName: json['organization_name'] ?? '',
      phone: json['phone'] ?? '',
      createdAt: DateTime.parse(json['created_at']),
    );
  }
}
