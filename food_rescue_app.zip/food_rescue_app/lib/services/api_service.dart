import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://10.0.2.2/food_rescue_api';


  static Future<Map<String, dynamic>> register(Map<String, String> userData) async {
    try {
      print('🔍 DEBUG: Attempting register to: $baseUrl/auth/register.php');
      print('🔍 DEBUG: User data: $userData');

      final response = await http.post(
          Uri.parse('$baseUrl/auth/register.php'),
          body: userData
      ).timeout(const Duration(seconds: 10));

      print('📡 DEBUG: Register response status: ${response.statusCode}');
      print('📡 DEBUG: Register response body: ${response.body}');

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      print('❌ DEBUG: Register error: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  static Future<Map<String, dynamic>> login(String username, String password) async {
    try {
      print('🔍 DEBUG: Attempting login to: $baseUrl/auth/login.php');
      print('🔍 DEBUG: Username: $username');

      final response = await http.post(
        Uri.parse('$baseUrl/auth/login.php'),
        body: {
          'username': username,
          'password': password,
        },
      ).timeout(const Duration(seconds: 10));

      print('📡 DEBUG: Login response status: ${response.statusCode}');
      print('📡 DEBUG: Login response body: ${response.body}');

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}'
        };
      }
    } catch (e) {
      print('❌ DEBUG: Login error: $e');
      return {
        'success': false,
        'message': 'Network error: Cannot connect to server. Check if XAMPP is running.'
      };
    }
  }

  static Future<Map<String, dynamic>> createFoodListing(Map<String, String> listingData) async {
    try {
      print('🔍 DEBUG: Attempting create listing to: $baseUrl/food/create_listing.php');
      print('🔍 DEBUG: Listing data: $listingData');

      final response = await http.post(
          Uri.parse('$baseUrl/food/create_listing.php'),
          body: listingData
      ).timeout(const Duration(seconds: 10));

      print('📡 DEBUG: Create listing response status: ${response.statusCode}');
      print('📡 DEBUG: Create listing response body: ${response.body}');

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      print('❌ DEBUG: Create listing error: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  static Future<Map<String, dynamic>> getFoodListings() async {
    try {
      print('🔍 DEBUG: Attempting get listings from: $baseUrl/food/get_listings.php');

      final response = await http.get(
          Uri.parse('$baseUrl/food/get_listings.php')
      ).timeout(const Duration(seconds: 10));

      print('📡 DEBUG: Get listings response status: ${response.statusCode}');
      print('📡 DEBUG: Get listings response body: ${response.body}');

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      print('❌ DEBUG: Get listings error: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  static Future<Map<String, dynamic>> getMyListings(int restaurantId) async {
    try {
      print('🔍 DEBUG: Attempting get my listings from: $baseUrl/food/get_my_listings.php?restaurant_id=$restaurantId');

      final response = await http.get(
          Uri.parse('$baseUrl/food/get_my_listings.php?restaurant_id=$restaurantId')
      ).timeout(const Duration(seconds: 10));

      print('📡 DEBUG: Get my listings response status: ${response.statusCode}');
      print('📡 DEBUG: Get my listings response body: ${response.body}');

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      print('❌ DEBUG: Get my listings error: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }
}
