package com.example.food_rescue_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
